# utils.py
#       It includes a custom Dataset class, a function to set the random seed for reproducibility, and a function to compute entropy.

import torch
import numpy as np
import random 
from torch.utils.data import Dataset
import torch.nn.functional as F
import os
from glob import glob
from PIL import Image
from torch.utils.data import DataLoader

# Compute saliency maps with the modified model
# def compute_saliency_modified(model, image, target_class):
#     model.eval()
#     image = image.unsqueeze(0).to(device)
#     image.requires_grad_()
#     output = model(image)
#     score = output[0, target_class]
#     score.backward()
#     saliency, _ = torch.max(image.grad.data.abs(), dim=1)
#     return saliency.squeeze().cpu().numpy()


# Occlusion analysis with the modified model
def occlusion_analysis_modified(model, image, target_class, occlusion_size=10):
    model.eval()
    image = image.unsqueeze(0).to(device)
    base_output = F.softmax(model(image), dim=1)[0, target_class].item()
    h, w = image.shape[2], image.shape[3]
    occlusion_map = np.zeros((h, w))
    for i in range(0, h, occlusion_size):
        for j in range(0, w, occlusion_size):
            occluded_image = image.clone()
            occluded_image[:, :, i:i+occlusion_size, j:j+occlusion_size] = 0
            output = F.softmax(model(occluded_image), dim=1)[0, target_class].item()
            occlusion_map[i:i+occlusion_size, j:j+occlusion_size] = base_output - output
    return occlusion_map

def print_framed_metrics(val_loss, val_acc):
    """
    Prints validation loss and accuracy inside a pretty ASCII box.
    """
    msg = f"Validation Loss: {val_loss:.4f}, Validation Accuracy: {val_acc:.4f}"
    border = '+' + '-' * (len(msg) + 2) + '+'
    print(border)
    print(f"| {msg} |")
    print(border)


def set_seed(seed=42):
    '''
    To have reproducible results EVERY time the code is ran, we set the seed for ALL random number generators.
    This includes numpy, random, and torch.
    '''
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    
def load_problem2_data():
    import numpy as np
    import os

    train_path = os.path.join('data', 'problem2', 'training_data.npz')
    val_path = os.path.join('data', 'problem2', 'evaluation_data.npz')

    training_data = np.load(train_path)
    training_images = training_data['a']
    training_labels = training_data['b']

    val_data = np.load(val_path)
    val_images = val_data['a']
    val_labels = val_data['b']

    print('training_images shape:', training_images.shape)
    print('training_labels shape:', training_labels.shape)
    print('val_images shape:', val_images.shape)
    print('val_labels shape:', val_labels.shape)

    return training_images, training_labels, val_images, val_labels

def compute_npz_mean_std(source):
    """
    Computes per-channel mean and standard deviation from image data.
    
    If source is a string, it is treated as the path to an NPZ file that contains image data under key 'a'.
    If source is a NumPy array, it is assumed to be the image data.
    
    If the images are of type uint8, they are normalized to [0, 1].
    
    Parameters:
        source (str or np.ndarray): File path to an NPZ file or a NumPy ndarray containing image data.
    
    Returns:
        mean (np.array): Per-channel mean.
        std (np.array): Per-channel standard deviation.
    """
    import numpy as np

    if isinstance(source, str):
        data = np.load(source)
        images = data['a']
    elif isinstance(source, np.ndarray):
        images = source
    else:
        raise ValueError("source must be a file path or a numpy ndarray.")

    # Normalize if images are uint8
    if images.dtype == 'uint8':
        images = images.astype(np.float32) / 255.0

    if images.ndim != 4:
        raise ValueError(f"Expected a 4D array but got shape {images.shape}")

    # Determine the image format and compute statistics
    if images.shape[1] == 3:
        # images in (N, C, H, W) format
        mean = np.mean(images, axis=(0, 2, 3))
        std = np.std(images, axis=(0, 2, 3))
    elif images.shape[3] == 3:
        # images in (N, H, W, C) format
        mean = np.mean(images, axis=(0, 1, 2))
        std = np.std(images, axis=(0, 1, 2))
    else:
        raise ValueError(f"Could not determine image format from shape {images.shape}")

    print("Computed mean:", mean)
    print("Computed std:", std)
    return mean, std

class ImageDataset(Dataset):
    """
    Loads images stored in a NumPy array.
    images : (N, 96, 96, 3) or (N, 3, 96, 96)
    labels : (N,) or None
    transform : torchvision transform taking a Tensor(3,96,96)
    device : the torch.device to move tensors to
    """
    def __init__(self, images: np.ndarray, labels: np.ndarray = None, transform=None, device='cpu'):
        self.images = images.astype(np.float32) / 255.0
        self.labels = labels
        self.transform = transform
        self.device = device

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = self.images[idx]

        if img.ndim == 3 and img.shape[-1] == 3:  # HWC → CHW
            img = np.transpose(img, (2, 0, 1))

        img = torch.from_numpy(img)  # float32 tensor in CHW
        if self.transform:
            img = self.transform(img)

        # Move to GPU (or specified device)
        img = img.to(self.device, non_blocking=True)

        if self.labels is not None:
            label = torch.tensor(self.labels[idx], dtype=torch.long, device=self.device)
            return img, label
        else:
            return img



    # def __getitem__(self, idx):
    #     img = self.images[idx].astype(np.float32) / 255.0  # Normalize

    #     # Convert from (C, H, W) → (H, W, C) for torchvision
    #     img = np.transpose(img, (1, 2, 0))

    #     if self.transform:
    #         img = self.transform(img)  # e.g., ToPILImage → Flip → ToTensor()

    #     # Final shape is already CHW because ToTensor() does it
    #     if self.labels is not None:
    #         label = self.labels[idx]
    #         return img, torch.tensor(label, dtype=torch.long)
    #     else:
    #         return img



    # def __getitem__(self, idx):
    #     img = self.images[idx].astype(np.float32) # Convert to float32 
    #     # Example: scale images to [0,1], convert to CHW
    #     img = img / 255.0 # Normalize to [0, 1]
    
    #     if img.shape[-1] == 3:  # Assume HWC format
    #         img = np.transpose(img, (2, 0, 1))  # (C, H, W)

    #     # img = np.transpose(img, (2, 0, 1))  # (3,96,96)

    #     if self.transform:
    #         # Apply any custom transforms (e.g. augmentations)
    #         img = self.transform(img)
        
    #     if self.labels is not None:
    #         label = self.labels[idx]
    #         return torch.tensor(img, dtype=torch.float), torch.tensor(label, dtype=torch.long)
    #     else:
    #         # For unlabeled data
    #         return torch.tensor(img, dtype=torch.float)



def create_dataloaders(
    train_dataset=None,
    val_dataset=None,
    batch_size=32,
    num_workers=None,
    pin_memory=True,
    mode='both',
    shuffle_train=True,
    shuffle_val=False
):
    """
    Creates PyTorch dataloaders for training and/or validation.

    Args:
        train_dataset (Dataset): Dataset for training.
        val_dataset (Dataset): Dataset for validation.
        batch_size (int): Batch size for loading.
        num_workers (int, optional): CPU workers for data loading. If None, uses (cpu_count - 1) safely.
        pin_memory (bool): If True, pin memory (recommended for GPU training).
        mode (str): 'train', 'val', or 'both' – selects which loaders to return.
        shuffle_train (bool): Whether to shuffle training data (default: True).
        shuffle_val (bool): Whether to shuffle validation data (default: False).

    Returns:
        dict: Dictionary containing one or both of the keys: 'train', 'val'
    """
    if num_workers is None:
        num_workers = 0 # max(0, (os.cpu_count() or 2) - 1)

    loaders = {}

    if mode in ['train', 'both']:
        assert train_dataset is not None, "train_dataset must be provided when mode is 'train' or 'both'"
        loaders['train'] = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=shuffle_train,
            num_workers=num_workers,
            pin_memory=pin_memory,
            persistent_workers=num_workers > 0
        )

    if mode in ['val', 'both']:
        assert val_dataset is not None, "val_dataset must be provided when mode is 'val' or 'both'"
        loaders['val'] = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=shuffle_val,
            num_workers=num_workers,
            pin_memory=pin_memory,
            persistent_workers=num_workers > 0
        )

    return loaders




def load_images_as_numpy(root_dir, image_size=(224, 224)):
    """
    Loads all images in a directory (recursively), resizes, and converts to NumPy array (N, H, W, C)
    """
    image_paths = glob(os.path.join(root_dir, '**', '*.*'), recursive=True)
    images = []

    for path in image_paths:
        try:
            img = Image.open(path).convert('RGB').resize(image_size)
            img_np = np.array(img).astype(np.float32) / 255.0  # (H, W, C), scaled
            images.append(img_np)
        except Exception as e:
            print(f"Skipped {path}: {e}")

    # Result: shape (N, H, W, C)
    return np.stack(images)


def compute_entropy(probabilities: np.ndarray) -> float:
    """
    Computes the entropy H(y_hat) = - sum(p_i log(p_i)) for a 1D array of probabilities.
    """
    eps = 1e-9
    p = np.clip(probabilities, eps, 1.0)
    return -np.sum(p * np.log(p))

def mc_dropout_inference(model, image, T=10, device='cuda'):
    """
    Perform MC Dropout inference on a single image using T stochastic forward passes.
    Assumes the model is already in .eval() mode with dropout manually enabled.
    
    Args:
        model: PyTorch model with dropout layers.
        image: Input image tensor (C, H, W), unbatched.
        T: Number of stochastic forward passes.

    Returns:
        mean_softmax: Mean predicted probabilities over T passes.
        entropy: Entropy of the mean prediction (measure of uncertainty).
    """
    model.to(device)  # ensure model is on correct device
    image = image.unsqueeze(0).to(device)  # add batch dim: (1, C, H, W)

    softmaxes = []
    with torch.no_grad():
        for _ in range(T):
            output = model(image)
            softmax = F.softmax(output, dim=1).squeeze().cpu()
            softmaxes.append(softmax)

    mean_softmax = torch.stack(softmaxes, dim=0).mean(dim=0)
    entropy = -torch.sum(mean_softmax * torch.log(mean_softmax + 1e-10)).item()
    return mean_softmax, entropy


def enable_dropout(model):
    """ Enable dropout layers during evaluation """
    for m in model.modules():
        if isinstance(m, torch.nn.Dropout):
            m.train()


if __name__ == "__main__":
    print("This is a utility module. It is not meant to be run directly.")