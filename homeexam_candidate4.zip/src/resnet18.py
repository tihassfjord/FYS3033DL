import torch.nn as nn
from torchvision.models import resnet18

def build_resnet18(num_classes=3):
    model = resnet18(pretrained=False)
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    return model

if __name__ == "__main__":
    model = build_resnet18()
    print(model)
    # Test the model with a random input
    x = torch.randn(1, 3, 224, 224)  # Batch size of 1, 3 channels, 224x224 image
    output = model(x)
    print(output.shape)  # Should be [1, num_classes]